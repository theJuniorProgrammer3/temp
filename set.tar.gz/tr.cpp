#include <iostream>
#include <dlib/dnn.h>
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>

using namespace std;
using namespace dlib;

//template <typename SUBNET> using outl = con<3, 64, 64, 2, 2, SUBNET>;
template <typename SUBNET> using hidl1 = relu<con<32, 3, 3, 1 , 1, SUBNET>>;
template <typename SUBNET> using outl = fc<12288, SUBNET>;
template <typename SUBNET> using hidl2 = relu<con<16, 3, 3, 1 , 1, SUBNET>>;

using nt = loss_mean_squared_multioutput<outl<hidl1<hidl2<input<matrix<rgb_pixel>>>>>>;
int main(){
	nt net;
	std::vector<matrix<rgb_pixel>> img28;
	std::vector<matrix<float>> img64
		;
	for(int i = 1; i <= 1000; i++) {
		ostringstream oss;
		oss << setw(5) << setfill('0') << i;
		string filename = "cats_low/cats_" + oss.str() + ".jpg";
		int width, h, c;
		unsigned char* imageStb = stbi_load(filename.c_str(), &width, &h, &c, 3);
		if(!imageStb) {
			cerr << "Gagal memuat gambar (low)!" << endl;
			return -1;
		}	
		matrix<rgb_pixel> image;
		image.set_size(h, width);
		for(int r = 0; r < h; r++) {
			for(int a = 0; a < width; a++) {
				unsigned char* px = imageStb + (r * width + a) * 3;
				image(r, a) = rgb_pixel(px[0], px[1], px[2]);
			}
		}
		img28.push_back(image);
		stbi_image_free(imageStb);

	}
	for(int i = 1; i <= 1000; i++) {
		ostringstream oss;
		oss << setw(5) << setfill('0') << i;
		string filename = "cats/cats_" + oss.str() + ".jpg";
		int width, h, c;
		unsigned char* imageStb = stbi_load(filename.c_str(), &width, &h, &c, 3);
		if(!imageStb) {
			cerr << "Gagal memuat gambar!" << endl;
			return -1;
		}	
		matrix<float> image(12'288, 1);
		for(int r = 0; r < 12'288; r++) {
				image(r, 0) = imageStb[r] ;
		}
		img64.push_back(image);
		stbi_image_free(imageStb);

	}
	dnn_trainer<nt> trainer(net);
	trainer.be_verbose();
	trainer.set_learning_rate(0.001);
	trainer.set_max_num_epochs(5000);
	trainer.train(img28, img64);/*
	int batch_size = 1; // Ukuran batch yang diinginkan
	for (size_t i = 0; i < img28.size(); i += batch_size) {
    		std::vector<matrix<rgb_pixel>> batch_images(img28.begin() + i, img28.begin() + std::min(i + batch_size, img28.size()));
    		std::vector<matrix<float>> batch_labels(img64.begin() + i, img64.begin() + std::min(i + batch_size, img64.size()));

    		trainer.train_one_step(batch_images, batch_labels);
	}*/
	return 0;
}
