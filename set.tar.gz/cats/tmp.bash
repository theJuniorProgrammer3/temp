for img in *.jpg; do
  magick "$img" -resize 28x28! "../cats_low/${img}";
done
